package com.pard.practice_tomorrow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeTomorrowApplication {

    public static void main(String[] args) {
        SpringApplication.run(PracticeTomorrowApplication.class, args);
    }

}
