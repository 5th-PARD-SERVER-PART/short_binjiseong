package com.pard.shortkathon.progress.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class UserNameReqDto {
    private String userName;
}
