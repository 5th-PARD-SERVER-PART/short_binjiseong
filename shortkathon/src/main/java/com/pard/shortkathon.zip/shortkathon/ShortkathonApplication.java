package com.pard.shortkathon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShortkathonApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShortkathonApplication.class, args);
    }

}
